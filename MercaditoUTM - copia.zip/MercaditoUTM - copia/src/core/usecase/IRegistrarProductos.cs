using MercaditoUTM.entities;

namespace MercaditoUTM.src.core.usecase
{
    public interface IRegistrarProductos
    {
        string RegistrarArticulo(string nombre, decimal precio, string sku, int stock, string marca);
    }
}