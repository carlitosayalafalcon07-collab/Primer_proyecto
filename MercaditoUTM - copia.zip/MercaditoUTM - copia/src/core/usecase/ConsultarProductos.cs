using System.Collections.Generic;
using MercaditoUTM.src.core.entities;

namespace MercaditoUTM.src.core.usecase
{
    public interface ConsultarProductos
    {
        List<Articulo> Ejecutar();
    }
}