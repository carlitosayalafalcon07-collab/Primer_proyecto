using System;

namespace MercaditoUTM.src.core.entities
{
    public class Articulo
    {
        public string? Nombre { get; set; }
        public decimal Precio { get; set; }
        public string? SKU { get; set; }
        public int Stock { get; set; }
        public string? Marca { get; set; }
    }
}