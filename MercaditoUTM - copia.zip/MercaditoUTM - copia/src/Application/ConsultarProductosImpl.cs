using System; // Required for Random
using System.Collections.Generic;
using MercaditoUTM.src.core.entities;
using MercaditoUTM.src.core.usecase;

namespace MercaditoUTM.src.Application
{
    public class ConsultarProductosImpl : ConsultarProductos
    {
        private readonly Random _random = new Random();

        public List<Articulo> Ejecutar()
        {
            List<Articulo> articulos = new List<Articulo>();
            string[] nombres = { "Teclado", "Monitor", "Impresora", "Webcam", "Auriculares", "Microfono", "Disco Duro", "Memoria RAM", "Tarjeta Gráfica", "Procesador" };
            string[] marcas = { "Logitech", "HP", "Dell", "Samsung", "Sony", "Kingston", "Nvidia", "Intel", "AMD", "Microsoft" };

            for (int i = 0; i < 25; i++)
            {
                articulos.Add(new Articulo
                {
                    Nombre = nombres[_random.Next(nombres.Length)],
                    Precio = Math.Round((decimal)(_random.NextDouble() * 1000) + 10, 2), // Price between 10 and 1010
                    SKU = $"SKU-{_random.Next(1000, 9999)}",
                    Stock = _random.Next(1, 100), // Stock between 1 and 99
                    Marca = marcas[_random.Next(marcas.Length)]
                });
            }
            return articulos;
        }
    }
}