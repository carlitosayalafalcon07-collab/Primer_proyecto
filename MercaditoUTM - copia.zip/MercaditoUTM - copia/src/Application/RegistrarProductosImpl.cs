using MercaditoUTM.src.core.usecase;
using MercaditoUTM.entities;

namespace MercaditoUTM.src.Application
{
    public class RegistrarProductosImpl : IRegistrarProductos
    {
        public string RegistrarArticulo(string nombre, decimal precio, string sku, int stock, string marca)
        {
            // Here you would typically interact with a data layer to persist the product.
            // For this example, we'll just check if the inputs are valid and return a success message.
            if (string.IsNullOrWhiteSpace(nombre) || precio <= 0 || string.IsNullOrWhiteSpace(sku) || stock <= 0 || string.IsNullOrWhiteSpace(marca))
            {
                return "Error: Todos los campos del producto son obligatorios y deben ser válidos.";
            }

            // In a real application, you would save the article to a database here.
            // Example: var newArticulo = new Articulo { Nombre = nombre, Precio = precio, SKU = sku, Stock = stock, Marca = marca };
            // _repository.Save(newArticulo);

            return "Producto añadido correctamente";
        }
    }
}