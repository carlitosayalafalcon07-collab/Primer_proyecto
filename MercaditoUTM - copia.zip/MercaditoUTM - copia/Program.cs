﻿using System;
using System.Collections.Generic;
using MercaditoUTM.src.core.usecase;
using MercaditoUTM.src.Application;
using MercaditoUTM.src.core.entities;

namespace MercaditoUTM
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ConsultarProductos consultarProductos = new ConsultarProductosImpl();
            IRegistrarProductos registrarProductos = new RegistrarProductosImpl();
            int opcion;

            do
            {
                Console.WriteLine("\n--- Menú Principal ---");
                Console.WriteLine("1. Consultar productos");
                Console.WriteLine("2. Registrar producto");
                Console.WriteLine("0. Salir");
                Console.Write("Ingrese una opción: ");

                if (int.TryParse(Console.ReadLine(), out opcion))
                {
                    switch (opcion)
                    {
                        case 1:
                            Console.WriteLine("\n--- Consultar Productos ---");
                            List<Articulo> articulos = consultarProductos.Ejecutar();
                            if (articulos.Count == 0)
                            {
                                Console.WriteLine("No hay artículos para mostrar.");
                            }
                            else
                            {
                                foreach (var articulo in articulos)
                                {
                                    Console.WriteLine($"- Nombre: {articulo.Nombre}, Precio: {articulo.Precio:C}, SKU: {articulo.SKU}, Stock: {articulo.Stock}, Marca: {articulo.Marca}");
                                }
                            }
                            break;
                        case 2:
                            Console.WriteLine("\n--- Registrar Producto ---");
                            Console.Write("Nombre: ");
                            string nombre = Console.ReadLine() ?? string.Empty;
                            Console.Write("Precio: ");
                            decimal precio;
                            while (!decimal.TryParse(Console.ReadLine(), out precio) || precio <= 0)
                            {
                                Console.WriteLine("Precio inválido. Intente de nuevo.");
                                Console.Write("Precio: ");
                            }
                            Console.Write("SKU: ");
                            string sku = Console.ReadLine() ?? string.Empty;
                            Console.Write("Stock: ");
                            int stock;
                            while (!int.TryParse(Console.ReadLine(), out stock) || stock <= 0)
                            {
                                Console.WriteLine("Stock inválido. Intente de nuevo.");
                                Console.Write("Stock: ");
                            }
                            Console.Write("Marca: ");
                            string marca = Console.ReadLine() ?? string.Empty;

                            string resultadoRegistro = registrarProductos.RegistrarArticulo(nombre, precio, sku, stock, marca);
                            Console.WriteLine(resultadoRegistro);
                            break;
                        case 0:
                            Console.WriteLine("Saliendo del programa.");
                            break;
                        default:
                            Console.WriteLine("Opción no válida. Intente de nuevo.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Entrada no válida. Por favor, ingrese un número.");
                }
            } while (opcion != 0);
        }
    }
}
